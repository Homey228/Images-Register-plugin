<?php

// Function to register all images from the 2012 folder
function register_all_images_from_2012_folder() {
    // Only clear all registered images when starting fresh (batch 0)
    $current_batch = get_option('image_processing_batch', 0);
    if ($current_batch == 0) {
        clear_all_registered_images();
    }

    // Now register images in the uploads/2012 folder
    register_images_metadata_in_2012_folder(true);
}

// Function to register only unregistered images from the 2012 folder
function register_unregistered_images_from_2012_folder() {
    // Register only unregistered images from the uploads/2012 folder
    register_images_metadata_in_2012_folder(false);
}

// Function to register images in the `uploads/2012` folder (only original images)
function register_images_metadata_in_2012_folder($clear_previous) {
    // Define the path to the specific folder (uploads/2012)
    $uploads_dir = wp_upload_dir()['basedir'] . '/2012/11';  // Target the 2012 folder

    // Check if the folder exists
    if (!is_dir($uploads_dir)) {
        echo '<div class="error"><p>The folder `uploads/2012` does not exist.</p></div>';
        return;
    }
    
    echo '<div>registering....</div>';
    
    // Get current batch number from WordPress options
    $current_batch = get_option('image_processing_batch', 0);
    
    // Recursively scan the uploads/2012 folder for image files
    $image_files = get_all_images($uploads_dir);
    
    // Calculate total images and batches
    $total_images = count($image_files);
    $batch_size = 100;
    $total_batches = ceil($total_images / $batch_size);
    
    // Calculate start and end indices for current batch
    $start_index = $current_batch * $batch_size;
    $end_index = min(($current_batch + 1) * $batch_size, $total_images);
    
    // Get current batch of images
    $current_batch_images = array_slice($image_files, $start_index, $batch_size);
    
    echo '<div class="updated"><p>Processing batch ' . ($current_batch + 1) . ' of ' . $total_batches . '</p>';
    echo '<p>Total images: ' . $total_images . ' (Processing ' . count($current_batch_images) . ' images in this batch)</p></div>';

    // Process current batch
    foreach ($current_batch_images as $image_path) {
        // Only register original images (skip scaled or resized versions)
        if (is_original_image($image_path)) {
            register_image_in_wordpress($image_path, $clear_previous);
        }
    }

    // Update batch number or reset if complete
    if ($end_index >= $total_images) {
        delete_option('image_processing_batch');
        echo '<div class="updated"><p>All batches completed! Total images processed: ' . $total_images . '</p></div>';
    } else {
        update_option('image_processing_batch', $current_batch + 1);
        echo '<div class="updated"><p>Batch ' . ($current_batch + 1) . ' completed. ';
        echo '<form method="post" style="display:inline;">';
        echo '<input type="hidden" name="register_images_action" value="' . 
             ($clear_previous ? 'register_all' : 'register_unregistered') . '" />';
        echo '<input type="submit" value="Process Next Batch" class="button-primary" />';
        echo '</form></p></div>';
    }
}

// Function to clear all registered images from the Media Library
function clear_all_registered_images() {
    // Get all media items (attachments) in the database
    $args = array(
        'post_type'      => 'attachment',
        'posts_per_page' => -1, // Get all attachments
        'post_status'    => 'any', // Include any post status
    );
    $attachments = get_posts($args);

    // Loop through all attachments and delete only the database entries
    foreach ($attachments as $attachment) {
        // Delete post metadata
        delete_post_meta_by_key('_wp_attachment_metadata');
        delete_post_meta_by_key('_wp_attached_file');
        delete_post_meta_by_key('_wp_attachment_image_alt');
        
        // Delete the post (attachment) from wp_posts table without touching the files
        wp_delete_post($attachment->ID, false);
    }

    echo '<div class="updated"><p>All image registrations have been cleared from the Media Library.</p></div>';
}
